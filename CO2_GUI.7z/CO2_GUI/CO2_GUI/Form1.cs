﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CO2_GUI
{
    public partial class Form1 : Form
    {

        private byte[] CRCcheck, CRCn, bytes, Setbytes, Buffer, bytesHub;
        private string IDnumber, Tempture, RGvalue, CO2value, SerialData, Co2ComPot, JsonPath;
        private string[] StrArray;
        private string[,] CutCRCArray, TabPosMapHub;
        private static Thread startup, Portstartup;
        private SerialPort sp;
        private DateTime GetNowDateTimeDetail = new DateTime(0001, 01, 01, 01, 01, 01, 01);
        private OleDbConnection connection = new OleDbConnection();
        private OleDbCommand command = new OleDbCommand();
        private OleDbDataReader Reader;
        private bool CheckCRCBool = false;
        private int B2RCount, CRCNumber, k, O, G, TTT, SetTime = 0;

        public Form1()
        {
            InitializeComponent();
            AccessBook();
            SerialData = "03,00,01,00,03";
            AccessSelectComPort("select ComPort from ComPort");
            sp = new SerialPort(Co2ComPot, 9600, Parity.None, 8);
            sp.Close();
            sp.Open();
        }

        private void AccessBook()
        {
            string mydocpath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            command.Connection = connection;
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + mydocpath + @"\CO2_GUI\CO2.accdb;";//Persist Security Info=False;Jet OLEDB:Database Password=;

        }
        private void Startup(object obj)
        {
            CRCn = new byte[2];
            string InsertValue = "SELECT Count(*) AS _Count FROM TabPosMap;";
            AccessSelect(InsertValue);

            try
            {
                for (int i = 0; i < (TabPosMapHub.Length / 2); i++)
                {
                    int tmpCount = 0, TFFcount = 1; // not move
                    byte byteTmp = Convert.ToByte(TabPosMapHub[i, 0], 16);
                    bytes = SerialData.Split(',').Select(s => Convert.ToByte(s, 16)).ToArray();
                    bytesHub = new byte[6];
                    bytesHub[0] = byteTmp;

                    foreach (byte TFF in bytes)
                    {
                        bytesHub[TFFcount] = TFF;
                        TFFcount++;
                    }

                    CheckCRC(bytesHub, ref CRCn, 1);
                    Setbytes = new byte[8];

                    foreach (byte TF in bytesHub)
                    {
                        Setbytes[tmpCount] = TF;
                        tmpCount++;
                    }
                    Setbytes[6] = CRCn[0];
                    Setbytes[7] = CRCn[1];
                    sp.Write(Setbytes, 0, Setbytes.Length);
                    Thread.Sleep(1000);
                }
                Portstartup = new Thread(PortStartup);
                Portstartup.Start();
            }
            catch (Exception ex)
            {
                Errordispaly(ex.ToString());
            }
        }

        private void PortStartup(object obj)
        {
            k = 0;
            foreach (byte xxx in Port_read(sp))
            {
                CRCcheck[k] = xxx;
                k++;
            }
            CRCNumber = CRCcheck.Length / 11;
            CutCRCArray = new string[CRCNumber, 11];
            O = 0;
            for (int i = 0; i < CRCNumber; i++)
            {
                for (int j = 0; j < 11; j++)
                {
                    CutCRCArray[i, j] = CRCcheck[O].ToString();
                    O++;
                }
            }

            for (int i = 0; i < CRCNumber; i++)
            {
                Setbytes = new byte[11];
                for (int H = 0; H < 11; H++)
                {
                    Setbytes[H] = Convert.ToByte(CutCRCArray[i, H], 10);
                }
                CheckCRC(Setbytes, ref CRCn, 0);
                if (CheckCRCBool) //CRC is Right
                {
                    FormatDisplay(Setbytes);

                    IDnumber = StrArray[0];
                    Tempture = StrArray[3] + StrArray[4];
                    RGvalue = StrArray[5] + StrArray[6];
                    CO2value = StrArray[7] + StrArray[8];

                    CountValues(IDnumber, Tempture, RGvalue, CO2value);
                }
                else
                {
                    Errordispaly(Setbytes[0] + "-" + "CheckCRC-Fail");
                    string InsertValueError = "insert into TabEVO values('Num','Num','Num','Num','" + CheckCRCBool.ToString() + "','" + GetNowDateTimeDetail.ToString("yyyy-MM-dd hh:mm:ss fff") + "')";
                    AccessInsert(InsertValueError);
                }
            }
            CheckCRCBool = false;
        }

        private delegate void errordispaly(string text); // ErrorDelegate
        private void Errordispaly(string text)
        {
            if (this.CRClabel.InvokeRequired)
            {
                errordispaly d = new errordispaly(Errordispaly);
                this.CRClabel.Invoke(d, new object[] { text });
            }
            else
            {
                CRClabel.Text = String.Format("{0}", text);
            }
        }
        //delegate void sccuessdispaly(string text);// SccuessDelegate
        //private void Sccuessdispaly(string text)
        //{
        //    if (this.textBox1.InvokeRequired)
        //    {
        //        sccuessdispaly d = new sccuessdispaly(Sccuessdispaly);
        //        this.textBox1.Invoke(d, new object[] { text });
        //    }
        //    else
        //    {
        //        textBox1.Text += String.Format("{0}", text) + Environment.NewLine;
        //        textBox1.SelectionStart = textBox1.Text.Length;
        //        textBox1.ScrollToCaret();
        //    }
        //}

        private void CheckCRC(byte[] message, ref byte[] CRC, int Number) // message : Modbus指令 ； CRC : 2 Byte Checksum
        {
            ushort CRCFull = 0xFFFF; // CRC 的初值設成 0xFFFF
            byte CRCHigh = 0xFF, CRCLow = 0xFF; // CRC 的 High byte 和 Low byte
            char CRCLSB; // CRC Least signficant bit

            switch (Number)
            {
                case 0:
                    for (int i = 0; i < (message.Length) - 2; i++)
                    {
                        CRCFull = (ushort)(CRCFull ^ message[i]); // exclusive or 

                        for (int j = 0; j < 8; j++)
                        {
                            CRCLSB = (char)(CRCFull & 0x0001); // 取得 Least signficant bit
                            CRCFull = (ushort)((CRCFull >> 1) & 0x7FFF); // 移去 Least signficant bit，前補0

                            if (CRCLSB == 1) // 如果 Least signficant bit 為 1
                                CRCFull = (ushort)(CRCFull ^ 0xA001);
                        }
                    }
                    CRC[1] = CRCHigh = (byte)((CRCFull >> 8) & 0xFF); // CRC high byte 在後
                    CRC[0] = CRCLow = (byte)(CRCFull & 0xFF); // CRC low byte 在前
                    if (message[message.Length - 1].ToString() == CRC[1].ToString() && message[message.Length - 2].ToString() == CRC[0].ToString())
                    {
                        CheckCRCBool = true;
                    }
                    else
                    {
                        CheckCRCBool = false;
                    }
                    break;

                case 1:
                    for (int i = 0; i < message.Length; i++)
                    {
                        CRCFull = (ushort)(CRCFull ^ message[i]); // exclusive or 

                        for (int j = 0; j < 8; j++)
                        {
                            CRCLSB = (char)(CRCFull & 0x0001); // 取得 Least signficant bit
                            CRCFull = (ushort)((CRCFull >> 1) & 0x7FFF); // 移去 Least signficant bit，前補0

                            if (CRCLSB == 1) // 如果 Least signficant bit 為 1
                                CRCFull = (ushort)(CRCFull ^ 0xA001);
                        }
                    }
                    CRC[1] = CRCHigh = (byte)((CRCFull >> 8) & 0xFF); // CRC high byte 在後
                    CRC[0] = CRCLow = (byte)(CRCFull & 0xFF); // CRC low byte 在前
                    break;
            }
        }

        /// <summary>
        /// 計算ID,℃,%,ppm並顯示在TextBox中
        /// </summary>
        /// <param name="ID">輸入ID代碼</param>
        /// <param name="Tv">輸入TemperTure代碼</param>
        /// <param name="RH">輸入RH代碼</param>
        /// <param name="CoTwo">輸入CO2代碼</param>
        private void CountValues(string ID, string Tv, string RH, string CoTwo) //Deivce的數值回收後,把數值轉換需要的型態16進制
        {
            GetNowDateTimeDetail = DateTime.Now;
            float IDNumber = Int32.Parse(ID, System.Globalization.NumberStyles.HexNumber);
            float TVValues = Int32.Parse(Tv, System.Globalization.NumberStyles.HexNumber) / 10.0f;
            float RHValues = Int32.Parse(RH, System.Globalization.NumberStyles.HexNumber) / 10.0f;
            float CoTwoValues = Int32.Parse(CoTwo, System.Globalization.NumberStyles.HexNumber);
            string InsertValue = "insert into TabEVO values('" + IDNumber + "','" + TVValues + "','" + RHValues + "','" + CoTwoValues + "','" + CheckCRCBool.ToString() + "','" + GetNowDateTimeDetail.ToString("yyyy-MM-dd hh:mm:ss fff") + "')";
            AccessInsert(InsertValue);
            //Sccuessdispaly(String.Format("ID={0}\tTemp={1}℃\tRH={2}%\tCO2V={3}ppm\t\tDate={4}", IDNumber.ToString(), TVValues.ToString(), RHValues.ToString(), CoTwoValues.ToString(), GetNowDateTimeDetail.ToString("yyyy-MM-dd hh:mm:ss")));
        }

        /// <summary>
        /// PadLeft(2, '0')來補足左邊位元的差異
        /// </summary>
        /// <param name="Array">位元byte</param>
        private void FormatDisplay(byte[] Array)//處理資料,如資料不足兩位數,自動左邊補零
        {
            StrArray = new string[Array.Length];
            G = 0;
            foreach (byte _data in Array)
            {
                StrArray[G] = Convert.ToString(_data, 16).PadLeft(2, '0');
                G++;
            }
        }

        private byte[] Port_read(SerialPort sp) //Deivce 回應計算處
        {
            B2RCount = sp.BytesToRead;
            Buffer = CRCcheck = new byte[B2RCount];
            if (B2RCount > 0)
            {
                sp.Read(Buffer, 0, B2RCount);
            }
            return Buffer;
        }

        private void Start_Tick(object sender, EventArgs e) //Lable is loop display number
        {
            label1.Text = SetTime.ToString();
            SetTime++;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                startup = new Thread(Startup);
                startup.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("請選擇ComPort", "ComPortError", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer.Enabled = true;
            Start.Enabled = true;
            StartButton.Text = "我已經請動了,請勿按我";
        }
        private int TabPosMapTmpCount;
        /// <summary>
        /// Insert something to Access
        /// </summary>
        /// <param name="_input"></param>
        private void AccessInsert(string _input)
        {
            connection.Open();
            command.CommandText = _input; //"insert into TabEVO values('1','1','1','1','1','1','1')";
            command.ExecuteNonQuery();
            connection.Close();
        }

        /// <summary>
        /// Select something from Access
        /// </summary>
        /// <param name="_input"></param>
        private void AccessSelect(string _input)
        {

            connection.Open();
            command.CommandText = _input; //"select * from xxx";
            Reader = command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    TabPosMapTmpCount = Int32.Parse(Reader["_Count"].ToString());
                }
            }
            connection.Close();
            connection.Open();
            TTT = 0;
            TabPosMapHub = new string[TabPosMapTmpCount, 2];
            command.CommandText = "select ID from TabPosMap";
            Reader = command.ExecuteReader();

            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    TabPosMapHub[TTT, 1] = TabPosMapTmpCount.ToString();
                    TabPosMapHub[TTT, 0] = Reader["ID"].ToString();
                    TTT++;
                }
            }
            connection.Close();
        }
        private void AccessSelectComPort(string _input)
        {
            connection.Open();
            command.CommandText = _input;
            Reader = command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    Co2ComPot = Reader["ComPort"].ToString();
                }
            }
            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer.Enabled = false;
            Start.Enabled = false;
            SetTime = 0;
            label1.Text = SetTime.ToString();
            StartButton.Text = "Start";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
